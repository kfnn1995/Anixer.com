<?php
/**
 *
 * The template for displaying footer
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}
?>
			
			<?php get_template_part( 'template-parts/footer/footer' )?>

        <?php wp_footer();?>

    </body>

</html>