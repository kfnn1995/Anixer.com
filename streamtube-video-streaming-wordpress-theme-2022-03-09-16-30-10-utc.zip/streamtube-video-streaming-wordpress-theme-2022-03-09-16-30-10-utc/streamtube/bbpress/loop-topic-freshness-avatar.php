<div class="bbp-topic-avatar me-4">
	<?php bbp_author_link( array( 
		'post_id'	=>	bbp_get_topic_last_active_id(),
		'type'		=>	'avatar',
		'size'		=>	get_option( 'avatar_size', 64 )
	) ); ?>
</div>