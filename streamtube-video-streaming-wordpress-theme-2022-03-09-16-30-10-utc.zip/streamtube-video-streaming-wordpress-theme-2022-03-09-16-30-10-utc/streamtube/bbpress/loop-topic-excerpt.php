<div class="bbp-topic-excerpt">
	<?php bbp_topic_excerpt( bbp_get_topic_id(), 100 ); ?>
</div>