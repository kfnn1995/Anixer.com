<div class="bbp-page-header py-5 bg-white">
	<div class="container">

		<h1 class="page-title forum-title h3"><?php the_title();?></h1>

		<?php bbp_breadcrumb(); ?>

	</div>
</div>
