<?php
/**
 *
 * The template for displaying page boxed
 *
 * Template Name: Page - Boxed
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}

get_header();
?>

    <?php get_template_part( 'template-parts/page', 'header' )?>

    <div class="page-main pt-4">

        <div class="container">
        
            <?php if( have_posts() ):?>

                <?php while( have_posts() ): the_post();?>

                    <div class="shadow-sm bg-white mb-4">
                        <article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

                            <div class="post-body single-body">

                                <?php if( has_post_thumbnail() ) : ?>
                                    <div class="post-main">
                                        <a title="<?php echo esc_attr( get_the_title() )?>" href="<?php echo esc_url( get_permalink() )?>">
                                            <div class="post-thumbnail">
                                                <?php the_post_thumbnail( 'post-thumbnails', array(
                                                    'class' =>  'img-fluid'
                                                ) );?>
                                            </div>
                                        </a>
                                    </div>
                                <?php endif;?>

                                <div class="post-bottom p-lg-5 p-3">

                                    <div class="post-content">
                                        <?php the_content( esc_html__( 'Continue reading', 'streamtube' ) );?>
                                        <div class="clearfix"></div>

                                        <?php wp_link_pages( array(
                                            'type'  =>  'list'
                                        ) );?>                
                                    </div>

                                </div>        
                            </div>

                        </article>
                    </div>

                <?php endwhile;?>

            <?php endif;?>

        </div>

    </div>

<?php 
get_footer();