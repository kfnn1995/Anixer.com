<?php
/**
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}
?>
<div class="header-theme-switcher">
    <button class="btn theme-switcher outline-none shadow-none" id="theme-switcher">
        <span class="btn__icon icon-moon"></span>        
    </button>  
</div>