<?php
/**
 * The post views meta template
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.8
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}

if( ! function_exists( 'streamtube_core' ) || ! method_exists( streamtube_core()->get()->post, 'get_post_views' ) ){
    return;
}

$args = wp_parse_args( $args, array(
    'realtime'  =>  false
) );

$pageviews = 0;

if( $args['realtime'] === false ){
    $pageviews = streamtube_core()->get()->post->get_post_views();

    if( $pageviews == 0 ){
        return;
    }
}

$view_type = get_option( 'sitekit_pageview_type', 'pageviews' );

?>

<div class="post-meta__views" data-post-view="<?php the_ID(); ?>">

    <span class="icon-eye"></span>

    <?php if( $pageviews ):?>
        <?php printf(_n( '%s view', '%s views', $pageviews, 'streamtube' ), streamtube_core_format_page_views( $pageviews )); ?>
    <?php endif; ?>

    <?php if( $args['realtime'] === true ): ?>

        <?php get_template_part( 'template-parts/spinner', '', array( 'type' => 'secondary' ) ); ?>
        <script type="text/javascript">
            var restUrl = '<?php echo rest_url(); ?>';
            jQuery.get( restUrl + '<?php echo 'streamtube/v1/analytics/totalviews/' . get_the_ID(); ?>', function( response ){
                if( response.success == true ){

                    var data = response.data;

                    var pageViews = 0;

                    <?php
                    switch ( $view_type ) {
                        case 'pageviews':
                            ?>
                            pageViews = data.page_views.response[0];
                            <?php
                        break;
                        
                        case 'uniquepageviews':
                            ?>
                            pageViews = data.page_views.response[1];
                            <?php
                        break;

                        case 'playevents':
                            ?>
                            pageViews = data.video_views.response[0];
                            <?php
                        break;

                        case 'uniqueplayevents':
                            ?>
                            pageViews = data.video_views.response[1];
                            <?php
                        break;                         

                    }
                    ?>

                    pageViews = parseInt( pageViews );

                    if( pageViews !== undefined || ! isNaN( pageViews ) ){
                        if( pageViews == 1 ){
                            pageViews = '<?php esc_html_e( '1 view', 'streamtube' );?>';
                        }else{
                            pageViews = pageViews.toLocaleString() + ' ' +'<?php esc_html_e( 'views', 'streamtube' );?>';
                        }

                        jQuery( '[data-post-view=<?php the_ID();?>] .spinner-border' ).replaceWith( pageViews );
                    }else{
                        jQuery( '[data-post-view=<?php the_ID();?>]' ).remove();
                    }
                }
            } );
        </script>
    <?php endif;?>
</div>