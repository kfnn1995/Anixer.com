<?php
/**
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}

global $post;
?>
<div class="post-meta d-md-flex align-items-center">

    <div class="post-meta__left post-meta__items mb-3 mb-xl-0">
        <?php
        /**
         * @since 1.0.8
         */
        do_action( 'streamtube/single/video/meta' );
        ?>       
    </div>

    <div class="post-meta__right post-options d-flex align-items-start justify-content-center ms-auto gap-2">

        <?php
        /**
         *
         * @since  1.0.0
         * 
         */
        do_action( 'streamtube/single/video/control' );
        ?>

        <?php if ( current_user_can( 'edit_post', get_the_ID() ) ):?>
            <div class="button-group">
                <button onclick="location.href = '<?php echo esc_url( streamtube_get_edit_post_link() )?>';" class="btn shadow-none d-flex align-items-center">
                    <span class="btn__icon icon-edit"></span>
                    <span class="btn__text small text-secondary"><?php esc_html_e( 'Edit', 'streamtube' )?></span>
                </button>
            </div>
        <?php endif;?>
    </div>
</div>