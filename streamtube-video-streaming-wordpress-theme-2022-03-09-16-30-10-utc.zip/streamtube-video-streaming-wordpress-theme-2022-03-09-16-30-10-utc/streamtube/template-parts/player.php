<?php
/**
 * The player template file
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
	exit;
}

if( ! function_exists( 'streamtube_core' ) ){
    return;
}

if( method_exists( streamtube_core()->get()->post , 'get_thumbnail_url' ) ){
    $poster = streamtube_core()->get()->post->get_thumbnail_url();
}
else{
    $poster = has_post_thumbnail() ? wp_get_attachment_image_url( get_post_thumbnail_id(), 'large' ) : '';
}

$args = wp_parse_args( $args, array(
    'post_id'       =>  get_the_ID(),
    'source'        =>  streamtube_core()->get()->post->get_source(),
    'poster'        =>  $poster,
    'poster_size'   =>  'large',
    'ratio'         =>  streamtube_core()->get()->post->get_aspect_ratio(),
    'autoplay'      =>  get_option( 'player_autoplay', 'on' ),
    'muted'         =>  get_option( 'player_mute' )
) );

if( is_attachment() && wp_attachment_is( 'video', get_the_ID() ) ){
    $args['source'] = get_the_ID();
}

get_template_part( 'template-parts/player', 'videojs', $args );