<?php
/**
 * The videojs template file
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
	exit;
}

wp_enqueue_style( 'streamtube-player' );

if( ! function_exists( 'streamtube_core' ) ){
	return;
}

$args = wp_parse_args( $args, array(
	'post_id'		=>	'',
	'uniqueid'		=>	uniqid(),
	'source'		=>	'',
	'poster'		=>	'',
	'poster_size'	=>	'large',
	'ratio'			=>	'21x9',
	'muted'			=>	false,
	'autoplay'		=>	true,	
) );

if( ! $args['poster'] ){
	if( wp_attachment_is( 'video', $args['source'] ) ){
		if( has_post_thumbnail( $args['source'] ) ){
			$args['poster'] = wp_get_attachment_image_url( get_post_thumbnail_id( $args['source'], $args['poster_size'] ) );
		}
	}
}

extract( $args );

?>
<?php printf(
	'<div class="player-wrapper %s" data-player-wrap-id="%s">',
	is_singular( 'video' ) && get_option( 'floating_player' ) ? 'jsappear' : 'no-jsappear',
	$post_id ? esc_attr( $post_id ) : $args['uniqueid']
)?>
	<?php printf(
		'<div class="player-wrapper-ratio ratio ratio-%s">',
		sanitize_html_class( $ratio )
	);?>

	<?php if( ! empty( $source ) ): ?>

		<div class="player-container">

			<?php if( is_singular( 'video' ) ): ?>

				<div class="player-header p-3">
					<div class="d-flex align-items-center">

						<?php the_title( '<h5 class="post-title post-title-md h5">', '</h5>' );?>

						<div class="ms-auto">
							<?php printf(
								'<button type="button" class="btn-close outline-none shadow-none" aria-label="%s"></button>',
								esc_html__( 'Close', 'streamtube' )
							);?>
						</div>
					</div>
				</div>	

			<?php endif;?>

		    <?php printf( '<div class="player-embed overflow-hidden bg-black ratio ratio-%s">', esc_attr( $ratio ) ); ?>
		    	<?php

		    		$techOrder = array();

		    		$src = $type = $ads_tag_url = '';

		    		$skin = get_option( 'player_skin', 'forest' );

		    		if( $skin == 'custom' ){
		    			$skin = get_option( 'player_skin_custom' );
		    		}

		    		if( wp_attachment_is( 'video', $source  ) ){
		    			$is_attachment = true;

		    			$src = wp_get_attachment_url( $source );

		    			if( strpos( $src , '.m3u8' ) !== false ){
		    				$type = 'application/x-mpegURL';
		    				wp_enqueue_script( 'videojs-contrib-quality-levels' );
		    				wp_enqueue_script( 'videojs-hls-quality-selector' );
		    			}
		    			else{
		    				$type = get_post_mime_type( $source );
		    			}
		    		}

		    		if( streamtube_is_youtube_url( $source ) ){
		    			$src = $source;
		    			$type = 'video/youtube';
		    			$techOrder[] = 'youtube';
		    		}

		    		if( streamtube_is_hls_url( $source ) ){
		    			$src = $source;
		    			$type = 'application/x-mpegURL';
		    		}		    		

		    		if( empty( $src ) ){
		    			$maybe_ext_url = pathinfo( $source );

		    			if( is_array( $maybe_ext_url ) && array_key_exists( 'extension', $maybe_ext_url ) ){
		    				if( in_array( strtolower( $maybe_ext_url['extension'] ), wp_get_video_extensions() ) ){
		    					$src = $source;
		    					$type = 'video/' . strtolower( $maybe_ext_url['extension'] );
		    				}
		    			}
		    		}

			    	if( ! empty( $src ) ):

			    		wp_enqueue_style( 'videojs' );

			    		if( in_array( $skin, array( 'city', 'forest', 'fantasy', 'sea' ) ) ){
			    			wp_enqueue_style( 'videojs-theme-' . $skin );	
			    		}

			    		if( $type == 'video/youtube' ){
			    			wp_enqueue_script( 'videojs-youtube' );
			    		}

			    		if( "" != $ads_tag_url = get_option( 'player_adtag_url' ) ){
			    			wp_enqueue_script( 'google-ima', '//imasdk.googleapis.com/js/sdkloader/ima3.js' );
			    			wp_enqueue_script( 'videojs-contrib-ads' );
				    		wp_enqueue_script( 'videojs-ima' );
				    		wp_enqueue_style( 'videojs-ima' );
			    		}

			    		wp_enqueue_script( 'player' );

			    		$setup = array(
			    			'mediaid'			=>	$post_id ? $post_id : $args['uniqueid'],
			    			'url'				=>	$post_id ? get_permalink( $post_id ) : '',
			    			'title'				=>	$post_id ? get_the_title( $post_id ) : '',
			    			'classes'			=>	array( 'video-js', 'position-absolute', 'videojs-streamtube' ),
			    			'controls'			=>	true,
			    			'muted'				=>	wp_validate_boolean( $muted ) ? true : false,
			    			'autoplay'			=>	wp_validate_boolean( $autoplay ) ? true : false,
			    			'preload'			=>	'auto',
			    			'poster'			=>	$poster ? $poster : '',
			    			'sources'			=>	array(
			    				array(
			    					'src'		=>	$src,
			    					'type'		=>	$type

			    				)
			    			),
			    			'load_hls'			=>	$type == 'application/x-mpegURL' ? true : false,
			    			'plugins'			=>	array(),
			    			'ads_tag_url'		=>	$ads_tag_url
			    		);

			    		if( ! empty( $skin ) ){
			    			$setup['classes'][] = 'vjs-theme-' . sanitize_html_class( $skin );	
			    		}
			    		

			    		if( is_embed() ){
			    			$setup['autoplay'] = false;
			    		}

			    		if( isset( $_GET['autoplay'] ) && wp_validate_boolean( $_GET['autoplay'] ) ){
			    			$setup['autoplay'] = true;
			    		}

			    		if( get_option( 'player_share', 'on' ) && $post_id ){
			    			$setup['plugins']['playerShareBox'] = array(
		    					'id'			=>	'share_box_' . $post_id,
		    					'url'			=>	streamtube_get_share_permalink( $post_id ),
		    					'embed_url'		=>	get_post_embed_url( $post_id ),
		    					'embed_width'	=>	560,
		    					'embed_height'	=>	315,
		    					'label_url'		=>	esc_html__( 'Link', 'streamtube' ),
		    					'label_iframe'	=>	esc_html__( 'Iframe', 'streamtube' )
			    			);
			    		}

			    		if( $post_id && "" != $logo_url = get_option( 'player_logo' ) ){
			    			if( is_embed() ){
				    			$setup['plugins']['playerLogo'] = array(
				    				'logo'		=>	$logo_url,
				    				'position'	=>	get_option( 'player_logo_position', 'top-right' ),
				    				'href'		=>	is_embed() ? get_permalink( $post_id ) : '#',
				    				'alt'		=>	get_bloginfo( 'name' )
				    			);
			    			}
			    		}

			    		if( "" != $control_bar_logo = get_option( 'player_control_logo' ) ){
			    			$setup['components']['controlBarLogo'] = array(
			    				'logo'		=>	$control_bar_logo,
			    				'href'		=>	is_embed() ? get_permalink( $post_id ) : '#',
			    				'alt'		=>	get_bloginfo( 'name' )
			    			);
			    		}

			    		if( $techOrder ){
			    			$setup['techOrder'] = $techOrder;
			    		}

			    		$autoplay 			= isset( $_GET['autoplay'] ) 	? wp_validate_boolean( $_GET['autoplay'] ) 	: $setup['autoplay'];
			    		$mute 				= isset( $_GET['mute'] ) 		? wp_validate_boolean( $_GET['mute'] ) 		: $setup['muted'];
			    		$controls 			= isset( $_GET['controls'] ) 	? wp_validate_boolean( $_GET['controls'] ) 	: $setup['controls'];
			    		$logo 				= isset( $_GET['logo'] ) 		? wp_validate_boolean( $_GET['logo'] ) 		: true;
			    		$share 				= isset( $_GET['share'] ) 		? wp_validate_boolean( $_GET['share'] ) 	: get_option( 'player_share', 'on' );

			    		$setup['autoplay'] = $autoplay;
			    		$setup['muted'] = $mute;
			    		$setup['controls'] = $controls;

			    		if( ! $share ){
			    			unset( $setup['plugins']['playerShareBox'] );
			    		}

			    		if( ! $logo ){
			    			unset( $setup['plugins']['playerLogo'] );
			    		}

			    		/**
			    		 *
			    		 * filter the player setup
			    		 *
			    		 * @param  array $setup
			    		 *
			    		 * @since  1.0.0
			    		 * 
			    		 */
			    		$setup = apply_filters( 'streamtube/player/file/setup', $setup, $source );

			    		$player = sprintf(
			    			'<video data-player-id="%1$s" id="%1$s" class="%2$s" data-setup="%3$s"></video>',
			    			$post_id ? $post_id : $args['uniqueid'],
			    			esc_attr( join(' ', $setup['classes'] ) ),
			    			esc_attr( json_encode( $setup ) )
			    		);

			    		/**
			    		 * Check if file is being encoded.
			    		 */
			    		if( function_exists( 'wp_video_encoder' ) && "" !== ( $queue = wpve_is_attachment_queue( $source ) ) ){
			    			
			    			if( $queue && in_array( $queue['status'], array( 'waiting', 'encoding' ) ) ){

			    				$post_title = get_the_title( $source );

			    				if( $post_id ){
			    					$post_title = get_the_title( $post_id );
			    				}

				    			do_action( "wp_video_encoder_running", $queue );
			    						    				
			    				ob_start();
			    				?>
			    				<div class="progress-wrap">
			    					<div class="w-50 top-50 start-50 translate-middle position-absolute">
			    						<h3 class="text-white h5 mb-4 fw-normal d-none d-sm-block">
			    							<?php printf(
			    								esc_html__( '%s is being encoded, please wait a minute.', 'streamtube' ),
			    								'<strong class="text-info">'. $post_title .'</strong>'
			    							);?>
			    						</h3>
			    						<?php wp_video_encoder()->get()->post->get_encode_status( $source );?>
			    					</div>
			    				</div>
			    				<?php
			    				$player = ob_get_clean();
			    			}
			    		}

			    		/**
			    		 *
			    		 * Fires before videojs loaded
			    		 *
			    		 * @since 1.0.9
			    		 * 
			    		 */
			    		do_action( 'streamtube/player/videojs/loaded', $player, $setup, $source );

			    		/**
			    		 *
			    		 * filter the player output
			    		 *
			    		 * @param  HTML $player
			    		 * @param  array $setup
			    		 * @param string $source
			    		 *
			    		 * @since  1.0.0
			    		 * 
			    		 */
			    		echo apply_filters( 'streamtube/player/file/output', $player, $setup, $source );

			    	else:
				    	$oembed_html = wp_oembed_get( $source  );

				    	if( ! $oembed_html ){
				    		$oembed_html = do_shortcode( $source  );
				    	}

			    		/**
			    		 *
			    		 * filter the oembed_html output
			    		 *
			    		 * @param  HTML $oembed_html
			    		 * @param  array $source
			    		 *
			    		 * @since  1.0.0
			    		 * 
			    		 */
			    		$oembed_html = apply_filters( 'streamtube/player/embed/output', $oembed_html, $source );				    	
				    	printf(
				    		'<div class="embed-responsive">%s</div>',
				    		$oembed_html
				    	);

				    endif;

		    		/**
		    		 *
		    		 * Fires after player loaded
		    		 *
		    		 * @since 1.0.9
		    		 * 
		    		 */
		    		do_action( 'streamtube/player/loaded', $source );

			    ?>
		    </div>
		</div>
	<?php
		else:
			printf(
				'<div class="video-not-found"><h3 class="position-absolute top-50 start-50 translate-middle">%s</h3></div>',
				esc_html__( 'Video unavailable', 'streamtube' )
			);
		endif;// end check if source is empty
	?>
	</div>
</div>