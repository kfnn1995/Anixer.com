<?php
/**
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
	exit;
}

$post_types = streamtube_get_search_post_types();

/**
 *
 * Filter the post types
 * 
 * @var array
 *
 * @since 1.0.5
 * 
 */
$post_types = apply_filters( 'streamtube/searchform/post_types', $post_types );
?>
<form action="<?php echo esc_url( home_url( '/' ) ); ?>" class="search-form d-flex" method="get">
	<button class="toggle-search btn btn-sm border-0 shadow-none d-block d-lg-none" type="button">
		<span class="icon-left-open"></span>
	</button>	
	<div class="input-group-wrap position-relative w-100">

		<?php if( is_array( $post_types ) && count( $post_types ) > 1 ): ?>

			<select class="form-control post-type-select search-type-select" name="post_type">
				<?php foreach ( $post_types as $post_type => $label ) : ?>
					<?php 

					if( streamtube_is_bbp_search() ){
						$_GET['post_type'] = 'topic';
					}

					$selected = isset( $_GET['post_type'] ) && $_GET['post_type'] == $post_type ? 'selected' : '';

					printf(
						'<option %s value="%s">%s</option>',
						$selected,
						esc_attr( $post_type ),
						esc_html( $label )
					);?>
				<?php endforeach; ?>
			</select>

		<?php endif;?>

		<?php printf(
			'<input aria-label="%s" class="form-control shadow-none ps-4" name="s" placeholder="%s" type="text" value="%s">',
			esc_attr__( 'Search', 'streamtube' ),
			esc_attr__( 'Search here...', 'streamtube' ),
			esc_attr( streamtube_get_search_query_value() )
		);?>

		<input type="hidden" name="search">

		<button class="btn btn-outline-secondary px-4 btn-main shadow-none" type="submit">
			<span class="btn__icon icon-search"></span>
		</button>
	</div>
</form>