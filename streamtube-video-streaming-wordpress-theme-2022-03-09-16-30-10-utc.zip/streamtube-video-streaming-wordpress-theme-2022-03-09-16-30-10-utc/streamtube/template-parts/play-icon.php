<?php
/**
 * The play icon template file
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}
?>
<div class="video-hover">
    <span class="icon-play top-50 start-50 translate-middle position-absolute"></span>
</div>