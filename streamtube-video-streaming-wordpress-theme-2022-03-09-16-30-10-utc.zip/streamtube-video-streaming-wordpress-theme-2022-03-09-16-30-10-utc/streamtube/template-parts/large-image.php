<?php
/**
 * The post large image template file
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}

$image_url = has_post_thumbnail() ? get_the_post_thumbnail_url( get_the_ID(), 'full' ) : '';

printf(
    '<div class="post-img fullwidth bg-cover %1$s" style="background-image: url(%2$s)">',
    $image_url ? 'has-image' : 'no-image',
    $image_url ? $image_url : ''
);?>

    <div class="post-header py-4">

        <div class="container">

            <article>

                <div class="post-meta">
                    <?php if( get_option( 'blog_post_category', 'on' ) ){
                        get_template_part( 'template-parts/post-category' );
                    }?>              
                    <?php
                         the_title(
                            '<h1 class="post-meta__title post-title post-title-xxl py-2">', '</h1>'
                        ); 
                    ?>

                    <div class="post-meta__items d-inline-block">                   

                        <div class="post-author me-3">
                            <div class="user-avatar user-avatar-sm d-inline-block me-2">
                                <?php printf(
                                    '<a href="%s">%s</a>',
                                    esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                                    get_avatar( get_the_author_meta( 'ID' ), null, null, null, array(
                                        'class' =>  'img-thumbnail p-0'
                                    ) )
                                );?>
                            </div>
                            <?php printf(
                                '<a href="%s">%s</a>',
                                esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ),
                                get_the_author()
                            );?>
                        </div>                

                        <?php get_template_part( 'template-parts/post-date-normal' ); ?>

                        <?php get_template_part( 'template-parts/post-comment', null, array( 'text' => true ) );?>

                        <?php get_template_part( 'template-parts/post-views', null, array( 'text' => true ) );?>
                        
                    </div><!--.post-meta__items-->

                </div>

            </article>

        </div>
    </div>

    <div class="bg-overlay"></div>

</div><!--.post-img fullwidth-->
