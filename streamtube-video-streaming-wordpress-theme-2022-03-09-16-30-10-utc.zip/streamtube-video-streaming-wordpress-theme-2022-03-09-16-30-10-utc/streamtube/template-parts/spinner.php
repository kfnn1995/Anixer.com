<?php
/**
 * The spinner template
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.8
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}

$args = wp_parse_args( $args, array(
	'type'	=>	'dark'
) );

?>
<div class="spinner-border text-<?php echo sanitize_html_class( $args['type'] ); ?>" role="status">
    <span class="visually-hidden">
        <?php esc_html_e( 'Loading...', 'streamtube' );?>
    </span>
</div>