<?php
/**
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}
?>
<article id="post-<?php the_ID(); ?>" <?php post_class(); ?>>

    <div class="post-body single-body">

        <?php if( has_post_thumbnail() ) : ?>
            <div class="post-main">
                <a title="<?php echo esc_attr( get_the_title() )?>" href="<?php echo esc_url( get_permalink() )?>">
                    <div class="post-thumbnail">
                        <?php the_post_thumbnail( 'post-thumbnails', array(
                            'class' =>  'img-fluid'
                        ) );?>
                    </div>
                </a>
            </div>
        <?php endif;?>

        <div class="post-bottom p-lg-5 p-3">

            <div class="post-meta">
                <?php 
                 the_title(
                    '<h1 class="post-meta__title post-title post-title-xxl py-2">', '</h1>'
                );    
                ?>
            </div>

            <div class="post-content">
                <?php the_content( esc_html__( 'Continue reading', 'streamtube' ) );?>
                <div class="clearfix"></div>

                <?php wp_link_pages( array(
                    'type'  =>  'list'
                ) );?>                
            </div>

        </div>        
    </div>

</article>