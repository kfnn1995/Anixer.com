<?php
/**
 *
 * The template for displaying float sidebar
 *
 * @link       https://1.envato.market/mgXE4y
 * @since      1.0.0
 *
 * @package    WordPress
 * @subpackage StreamTube
 * @author     phpface <nttoanbrvt@gmail.com>
 */
if( ! defined( 'ABSPATH' ) ){
    exit;
}

if( has_nav_menu( 'primary' ) || is_active_sidebar( 'secondary' ) ):?>

	<div id="sidebar-secondary" class="sidebar sidebar-secondary border-end bg-white no-scroll d-flex flex-column">

		<?php

		if( has_nav_menu( 'primary' ) ):
			echo '<div class="widget_main-menu">';
				wp_nav_menu( array(
					'theme_location'  	=> 'primary',
					'container'       	=> 'div',
					'container_class' 	=> 'main-nav float-nav',
					'container_id'   	=> 'main-nav',
					'menu_class'     	=> 'nav flex-column',
					'echo'				=> true,
					'fallback_cb'		=> 'WP_Bootstrap_Navwalker::fallback',
					'walker'        	=> new WP_Bootstrap_Navwalker(),
				) );
			echo '</div>';
		endif;

		if( is_active_sidebar( 'secondary' ) ){
			echo '<div class="widget-group p-3 mt-3">';

				dynamic_sidebar( 'secondary' );

			echo '</div>';	
		}
	
		?>
	</div>

<?php endif;